using System.Collections;
using System.Collections.Generic;

using UnityEngine;

public class ballController : MonoBehaviour
{
    public GameObject ball;
    public bool isKick=true;//蹴ったかどうか
    private bool isCollision=false;//ゴールキーパーかゴールに当たったらtrue,改めて蹴るときにfalse
    public gameController gameScript;
    public GameObject manager;
    public GameObject goal;
    goalController script;
    public GameObject GK;
    keeperController keeperScript;
    
    private bool isAbleKick=false;
    int kick;

    // Start is called before the first frame update
    void Start()
    {
        Rigidbody rb = this.GetComponent<Rigidbody> ();
        gameScript = manager.GetComponent<gameController>();
         goal = GameObject.FindWithTag("Goal");
          script = goal.GetComponent<goalController>();
          keeperScript = GK.GetComponent<keeperController>();
          Invoke("kickStart",0.5f);
        // kick=gameScript.kick;
    }

    // Update is called once per frame
    void FixedUpdate()
    { 
         Rigidbody rb = this.GetComponent<Rigidbody> ();
         Transform myTransform = this.transform;
         Vector3 pos = myTransform.position;
        if(isAbleKick){
            if(Input.GetKey(KeyCode.W) && isKick){
                rb.velocity = new Vector3(-50, 12, 0);
                isKick=false;
                keeperScript.isBlock=true;
            }
            if(Input.GetKey(KeyCode.A) && isKick){
            rb.velocity = new Vector3(-50, 12, -17);
            isKick=false;
            keeperScript.isBlock=true;
            }
            if(Input.GetKey(KeyCode.D) && isKick){
                rb.velocity = new Vector3(-50, 12, 17);
                isKick=false;
                keeperScript.isBlock=true; 
            }
             
        }
       
    }
    void kickStart(){
        isAbleKick=true;
    }
    void rekick(){
        Rigidbody rb = this.GetComponent<Rigidbody> ();
        ball.transform.position = new Vector3(7.0f, 0.5f, 0);
         rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        isKick=true;
        isCollision=false;
        keeperScript.rekick();
        if(gameScript.kick==5){
            isAbleKick=false;
        }
    }
        void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Goal") && !isCollision){
            isCollision=true;
            Debug.Log("Goal");
            script.score++;
            gameScript.kick++;
           Invoke("rekick", 3);
        }
        if(collision.gameObject.CompareTag("GK") && !isCollision){
            isCollision=true;
            Debug.Log("GK");
            gameScript.kick++;
           Invoke("rekick",3);
        }
    }
}

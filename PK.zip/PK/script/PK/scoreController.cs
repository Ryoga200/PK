using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class scoreController : MonoBehaviour
{
    public GameObject goal;
    goalController script;
    public TextMeshProUGUI scoreText;
    int score;
    void Start()
    {
         goal = GameObject.FindWithTag("Goal");
          script = goal.GetComponent<goalController>();
         score = script.score;
    }

    // Update is called once per frame
    void Update()
    {  score = script.score;
       scoreText.text=score.ToString()+"点";
    }
}

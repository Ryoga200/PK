using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class resultController : MonoBehaviour
{
    public TextMeshProUGUI restText;
    public GameObject resultCanvas;
    goalController script;
    GameObject goal;
    // Start is called before the first frame update
    void Start()
    {
         goal = GameObject.FindWithTag("Goal");
          script = goal.GetComponent<goalController>();
    }

    // Update is called once per frame
    void Update()
    {
        if(script.score<=3){
            restText.text="You lose";
        }else{
            restText.text="You win";
        }
         
    }
}

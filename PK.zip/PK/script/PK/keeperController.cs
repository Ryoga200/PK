using System;
using UnityEngine;

public class keeperController : MonoBehaviour
{
    public ballController ballScript;
    public GameObject ball;
    public bool isBlock=false;
    // Start is called before the first frame update
    int ranvec;
    void Start()
    {
        ballScript = ball.GetComponent<ballController>();
         isBlock = false;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
         var rand = new System.Random();
         Rigidbody rb = this.GetComponent<Rigidbody> ();
        Transform myTransform = this.transform;
         Vector3 pos = myTransform.position;
        if(isBlock){
           int ranvec=rand.Next(0,3);
        Debug.Log(ranvec);
        isBlock = false;
        if(ranvec==0){
            rb.velocity = new Vector3(0, 5, 0);
        }
        if(ranvec==1){
            rb.velocity = new Vector3(0, 3, 11);
              rb.transform.Rotate (5.0f, 0.0f, 0.0f, Space.World );
        }
        if(ranvec==2){
            rb.velocity = new Vector3(0, 3, -11);
              rb.transform.Rotate (-5.0f, 0.0f, 0.0f, Space.World );
        }
        }
        
    }
    public void rekick(){
        Rigidbody rb = this.GetComponent<Rigidbody> ();
        rb.transform.position = new Vector3(-7.0f, -0.5f, 0);
         rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        rb.transform.eulerAngles = new Vector3(0.0f, 90.0f, 0.0f);

    }
}

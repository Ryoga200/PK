using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class gameController : MonoBehaviour
{
    public int kick;
    public TextMeshProUGUI restText;
    public GameObject resultCanvas;
    // Start is called before the first frame update
    void Start()
    {
        kick=0;
        resultCanvas.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        restText.text=kick.ToString()+"蹴り目";
        if(kick==5){
             Invoke("result", 3.1f);
        }
    }
    void result(){
        resultCanvas.SetActive(true);
     }

}
